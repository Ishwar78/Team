import { useParams } from "react-router-dom";
import { useEffect, useState } from "react";
import axios from "axios";
import DashboardLayout from "@/components/DashboardLayout";
import { useAuth } from "@/contexts/AuthContext";

const UserDetails = () => {
  const { id } = useParams();
  const { token } = useAuth();
  const [sessions, setSessions] = useState([]);
  const [screenshots, setScreenshots] = useState([]);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    const sessionRes = await axios.get(`/api/sessions/user/${id}`, {
      headers: { Authorization: `Bearer ${token}` }
    });

    const shotRes = await axios.get(`/api/agent/screenshots/${id}`, {
      headers: { Authorization: `Bearer ${token}` }
    });

    setSessions(sessionRes.data.sessions);
    setScreenshots(shotRes.data.screenshots);
  };

  return (
    <DashboardLayout>
      <h1>User Details</h1>

      <h2>Sessions</h2>
      {sessions.map((s: any) => (
        <div key={s._id}>
          Start: {new Date(s.start_time).toLocaleString()}
        </div>
      ))}

      <h2>Screenshots</h2>
      {screenshots.map((s: any) => (
        <img
          key={s._id}
          src={`http://localhost:5000/uploads/${s.s3_key}`}
          width={300}
        />
      ))}
    </DashboardLayout>
  );
};

export default UserDetails;
