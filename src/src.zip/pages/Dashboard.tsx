import { useEffect, useState } from "react";
import axios from "axios";
import DashboardLayout from "@/components/DashboardLayout";
import { useAuth } from "@/contexts/AuthContext";

const Dashboard = () => {
  const { token } = useAuth();
  const [stats, setStats] = useState<any>(null);

  useEffect(() => {
    fetchStats();
  }, []);

  const fetchStats = async () => {
    const res = await axios.get("/api/dashboard/stats", {
      headers: { Authorization: `Bearer ${token}` }
    });
    setStats(res.data);
  };

  if (!stats) return <div>Loading...</div>;

  return (
    <DashboardLayout>
      <h1>Dashboard</h1>
      <p>Active Now: {stats.activeNow}</p>
      <p>Total Screenshots: {stats.screenshots}</p>
    </DashboardLayout>
  );
};

export default Dashboard;
