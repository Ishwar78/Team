// import { Router } from 'express';
// import { authenticate } from '../middleware/auth';
// import { requireRole } from '../middleware/roleGuard';
// import { Session } from '../models/Session';
// import { Screenshot } from '../models/Screenshot';

// const router = Router();

// router.get(
//   '/stats',
//   authenticate,
//   requireRole('company_admin', 'sub_admin'),
//   async (req, res) => {
//     const companyId = req.auth!.company_id;

//     const activeNow = await Session.countDocuments({
//       company_id: companyId,
//       status: 'active'
//     });

//     const screenshots = await Screenshot.countDocuments({
//       company_id: companyId
//     });

//     const today = new Date();
//     today.setHours(0, 0, 0, 0);

//     const hours = await Session.aggregate([
//       {
//         $match: {
//           company_id: companyId,
//           start_time: { $gte: today }
//         }
//       },
//       {
//         $group: {
//           _id: null,
//           total: { $sum: "$summary.total_duration" }
//         }
//       }
//     ]);

//     res.json({
//       activeNow,
//       screenshots,
//       hoursToday: hours[0]?.total || 0
//     });
//   }
// );

// export default router;


























import mongoose, { Schema, Document } from 'mongoose';

export interface IScreenshot extends Document {
  user_id: mongoose.Types.ObjectId;
  company_id: mongoose.Types.ObjectId;
  session_id: mongoose.Types.ObjectId;
  timestamp: Date;
  s3_key: string;
  s3_bucket: string;
  file_size: number;
  blurred: boolean;
}

const ScreenshotSchema = new Schema<IScreenshot>(
  {
    user_id: { type: Schema.Types.ObjectId, ref: 'User', required: true },
    company_id: { type: Schema.Types.ObjectId, ref: 'Company', required: true },
    session_id: { type: Schema.Types.ObjectId, ref: 'Session', required: true },
    timestamp: { type: Date, default: Date.now },
    s3_key: { type: String, required: true },
    s3_bucket: { type: String, default: 'local' },
    file_size: Number,
    blurred: { type: Boolean, default: false },
  },
  { timestamps: true }
);

export const Screenshot = mongoose.model<IScreenshot>(
  'Screenshot',
  ScreenshotSchema
);
