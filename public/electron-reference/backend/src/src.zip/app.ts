import express from 'express';
import helmet from 'helmet';
import cors from 'cors';

import { env } from './config/env';
import { rateLimiter } from './middleware/rateLimiter';
import { errorHandler } from './middleware/errorHandler';

import superAdminRoutes from './routes/superAdmin.routes';
import authRoutes from './routes/auth.routes';
import companyRoutes from './routes/company.routes';
import sessionRoutes from './routes/session.routes';
import activityRoutes from './routes/activity.routes';
import screenshotRoutes from './routes/screenshot.routes';
import adminRoutes from './routes/admin.routes';

const app = express();

/* ================= SECURITY ================= */

app.use(helmet());

/* ================= CORS FIX ================= */

// Allow multiple origins from .env
const allowedOrigins = env.CORS_ORIGIN
  ? env.CORS_ORIGIN.split(',').map(o => o.trim())
  : [];

app.use(
  cors({
    origin: (origin, callback) => {
      // Allow non-browser requests (Postman, curl)
      if (!origin) return callback(null, true);

      if (allowedOrigins.includes(origin)) {
        return callback(null, true);
      } else {
        console.log('❌ Blocked by CORS:', origin);
        return callback(new Error('Not allowed by CORS'));
      }
    },
    credentials: true,
  })
);
app.use('/uploads', express.static('uploads'));

/* ================= BODY PARSER ================= */

app.use(express.json({ limit: '1mb' }));

/* ================= RATE LIMIT ================= */

app.use(rateLimiter);

/* ================= HEALTH CHECK ================= */

app.get('/health', (_req, res) => {
  res.json({
    status: 'ok',
    uptime: process.uptime(),
    environment: env.NODE_ENV,
  });
});

/* ================= ROUTES ================= */

// Super Admin Routes
app.use('/api/super-admin', superAdminRoutes);

// Auth Routes
app.use('/api/auth', authRoutes);


app.use('/api/company', companyRoutes);
// Sessions
app.use('/api/sessions', sessionRoutes);

// Agent Activity
app.use('/api/agent/activity', activityRoutes);

// Screenshots
app.use('/api/agent/screenshots', screenshotRoutes);

// Admin Panel
app.use('/api/admin', adminRoutes);

/* ================= ERROR HANDLER ================= */

app.use(errorHandler);

export default app;
