import { Router } from 'express';
import bcrypt from 'bcryptjs';
import { authenticate } from '../middleware/auth';
import { requireRole } from '../middleware/roleGuard';
import { User } from '../models/User';
import { Company } from '../models/Company';
import { AppError } from '../utils/errors';

const router = Router();

/* Super Admin only */
router.use(authenticate);
router.use(requireRole('super_admin'));

/* Create Company */
router.post('/company', async (req, res) => {
  const { name, domain, adminEmail, adminPassword } = req.body;

  if (!name || !adminEmail || !adminPassword)
    throw new AppError('Missing fields', 400);

  const company = await Company.create({
    name,
    domain,
    max_users: 10,
  });

  const hashed = await bcrypt.hash(adminPassword, 10);

  const admin = await User.create({
    company_id: company._id,
    email: adminEmail,
    password_hash: hashed,
    name: 'Company Admin',
    role: 'company_admin',
    status: 'active',
  });

  res.status(201).json({
    company,
    admin: {
      id: admin._id,
      email: admin.email,
    },
  });
});

/* Get all companies */
router.get('/companies', async (_req, res) => {
  const companies = await Company.find().sort({ createdAt: -1 });
  res.json({ companies });
});

export default router;
