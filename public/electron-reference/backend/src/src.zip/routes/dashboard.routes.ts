import { Router } from 'express';
import { authenticate } from '../middleware/auth';
import { enforceTenant } from '../middleware/tenantIsolation';
import { requireRole } from '../middleware/roleGuard';
import { Session } from '../models/Session';
import { Screenshot } from '../models/Screenshot';

const router = Router();
router.use(authenticate, enforceTenant, requireRole('company_admin'));

router.get('/stats', async (req, res) => {
  const companyId = req.auth!.company_id;

  const activeNow = await Session.countDocuments({
    company_id: companyId,
    status: 'active'
  });

  const screenshots = await Screenshot.countDocuments({
    company_id: companyId
  });

  const hoursToday = await Session.aggregate([
    {
      $match: {
        company_id: companyId,
        start_time: { $gte: new Date(new Date().setHours(0,0,0,0)) }
      }
    },
    {
      $group: {
        _id: null,
        total: { $sum: "$summary.total_duration" }
      }
    }
  ]);

  res.json({
    activeNow,
    screenshots,
    hoursToday: hoursToday[0]?.total || 0
  });
});

export default router;
